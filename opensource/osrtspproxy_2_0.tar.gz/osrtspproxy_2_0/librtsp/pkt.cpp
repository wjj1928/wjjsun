/****************************************************************************
 *
 *  Copyright (C) 2000-2001 RealNetworks, Inc. All rights reserved.
 *
 *  This program is free software.  It may be distributed under the terms
 *  in the file LICENSE, found in the top level of the source distribution.
 *
 */

#include "pkt.h"
#include "dbg.h"

CPacket::CPacket( void )
{
    // Empty
}

CPacket::~CPacket( void )
{
    // Empty
}
